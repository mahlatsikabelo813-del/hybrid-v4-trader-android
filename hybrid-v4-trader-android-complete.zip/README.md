# Hybrid V4 Trader Android — Complete Source Project

This project builds an Android APK using GitHub Actions. It contains:
- Native Android WebView shell
- Mobile dashboard for NASDAQ / US Tech 100, Volatility 75 and Volatility 100
- V4 trend + dual momentum + breakout + sideways-market signal engine
- User-configurable daily signal limit, stake, cooldown and breakout lookback
- Deriv WebSocket market feed and account authorization UI
- No paper-trade results tracker

## Important limitations
This is a demo-first integration project, not a promise of profitable trading. Deriv market names and contract types vary by account/region. The app intentionally does **not** send buy/sell orders yet: the correct contract type and proposal fields must be confirmed for each active symbol, especially because US Tech 100 may use a different product/API workflow from synthetic indices. Do not use a real-account token.

## Build APK with GitHub
1. Upload the contents of this project to the root of your repository (not the ZIP file itself).
2. Commit the changes.
3. Open **Actions** and run the **Build Android APK** workflow.
4. Download `hybrid-v4-android-apk` from the successful run's Artifacts section.

## Deriv connection
- Create/register an application in the official Deriv developer dashboard and obtain its App ID.
- Put the App ID in `app/src/main/assets/index.html` at `DERIV_APP_ID`.
- For demo account testing, use the app's Connect Demo Account button and paste a demo API token locally into the app only. Never commit a token to GitHub or send it in chat.
- Token is held in page memory only and is not saved to localStorage. Disconnect/close the app to clear it.
- Use a token with only the permissions actually required. Avoid Admin scope for routine trading.

Official docs: https://developers.deriv.com/
