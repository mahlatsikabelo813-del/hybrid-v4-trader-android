# Hybrid V4 Trader Android — Complete Source Project

This project builds an Android APK through GitHub Actions. It includes:
- Mobile dashboard for NASDAQ / US Tech 100, Volatility 75 and Volatility 100
- V4 trend + dual momentum + breakout + sideways-market signal engine
- User-configurable daily signal limit, stake, cooldown and breakout lookback
- Public market feed and the newer Deriv PAT authentication flow
- Demo-account selection from the Options accounts returned by the API
- Demo-only OTP WebSocket guard: the app refuses a connection unless Deriv returns a URL ending in `/ws/demo`

## Safety and limitations

This is a demo-first integration project, not a promise of profitable trading. **Order execution remains locked.** This build only reads prices, generates signals and attempts to verify the demo account and balance. It does not place orders or simulate wins/losses. Market availability and contract types can vary by account/region.

Never paste your Personal Access Token into GitHub, screenshots, or chat. The token is used in app memory to request the account list and demo OTP; it is not written to localStorage or included in this source archive. Use the minimum permissions needed; do not use an admin token.

## Build in the existing GitHub repository

The repository workflow can extract this project archive, build the APK, and upload the APK as a GitHub Actions artifact. Keep the archive's expected file name in sync with the workflow.

## PAT connection

The app uses the newer Deriv REST authentication flow: `GET /trading/v1/options/accounts` with `Authorization: Bearer <PAT>` and `Deriv-App-ID`, then requests a one-time WebSocket URL for the selected demo account. It will not connect to a real-account WebSocket.

Official docs: https://developers.deriv.com/docs/intro/authentication/ and https://developers.deriv.com/docs/options/
