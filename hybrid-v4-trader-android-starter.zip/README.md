# Hybrid V4 Trader Android

Android project scaffold for the Hybrid V4 Deriv trading app.

## Current contents
- Android WebView shell
- Mobile dashboard UI for NASDAQ, Volatility 75, and Volatility 100
- V4-style signal engine (trend, momentum, breakout, sideways-market filter)
- User-configurable daily signal/trade limit and stake settings
- GitHub Actions workflow to build a debug APK

## Important status
This first scaffold is **not yet authorized to place trades**. It intentionally has no paper-results tracker and does not claim to execute orders. The next implementation step is to add Deriv's current authenticated demo-account workflow, validate available symbols/contracts, and test proposal/buy/contract monitoring on a demo account before enabling real trading.

Never put a Deriv password or API token into GitHub. The eventual app should collect credentials locally and use least-privilege permissions. Start with demo only.
